package com.typesafe.config.impl;

import com.typesafe.config.ConfigMergeable;
import com.typesafe.config.ConfigValue;

interface MergeableValue extends ConfigMergeable {
    // 将Config转换为其根对象，将ConfigValue转换为自身
    ConfigValue toFallbackValue();
}
