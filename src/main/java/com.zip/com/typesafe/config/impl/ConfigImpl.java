/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config.impl;

import com.typesafe.config.*;

import java.io.File;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.Callable;

/**
 * Internal implementation detail, not ABI stable, do not touch.
 * For use only by the {@link com.typesafe.config} package.
 */
public class ConfigImpl {

    private static class LoaderCache {
        private Config currentSystemProperties;
        private WeakReference<ClassLoader> currentLoader;
        private Map<String, Config> cache;

        LoaderCache() {
            this.currentSystemProperties = null;
            this.currentLoader = new WeakReference<ClassLoader>(null);
            this.cache = new HashMap<String, Config>();
        }

        // for now, caching as long as the loader remains the same,
        // drop entire cache if it changes.
        synchronized Config getOrElseUpdate(ClassLoader loader, String key, Callable<Config> updater) {
            //1判断ClassLoader是否是当前ClassLoader，若不是则清空缓存，设置当前ClassLoader
            if (loader != currentLoader.get()) {
                // reset the cache if we start using a different loader
                cache.clear();
                currentLoader = new WeakReference<ClassLoader>(loader);
            }

//            Config systemProperties = systemPropertiesAsConfig();TODO
//            if (systemProperties != currentSystemProperties) {
//                cache.clear();
//                currentSystemProperties = systemProperties;
//            }

            Config config = cache.get(key);
            if (config == null) {
                try {
                    config = updater.call();
                } catch (RuntimeException e) {
                    throw e; // this will include ConfigException
                } catch (Exception e) {
                    throw new ConfigException.Generic(e.getMessage(), e);
                }
                if (config == null)
                    throw new ConfigException.BugOrBroken("null config from cache updater");
                cache.put(key, config);
            }

            return config;
        }
    }

    private static class LoaderCacheHolder {
        static final LoaderCache cache = new LoaderCache();
    }

    public static Config computeCachedConfig(ClassLoader loader, String key,
            Callable<Config> updater) {
        LoaderCache cache;
        try {
            cache = LoaderCacheHolder.cache;
        } catch (ExceptionInInitializerError e) {
            throw ConfigImplUtil.extractInitializerError(e);
        }
        return cache.getOrElseUpdate(loader, key, updater);
    }

//    private static AbstractConfigObject loadSystemProperties() {
//        return (AbstractConfigObject) Parseable.newProperties(getSystemProperties(),
//                ConfigParseOptions.defaults().setOriginDescription("system properties")).parse();
//    }
//
//    private static class SystemPropertiesHolder {
//        // this isn't final due to the reloadSystemPropertiesConfig() hack below
//        static volatile AbstractConfigObject systemProperties = loadSystemProperties();
//    }
//
//    static AbstractConfigObject systemPropertiesAsConfigObject() {
//        try {
//            return SystemPropertiesHolder.systemProperties;
//        } catch (ExceptionInInitializerError e) {
//            throw ConfigImplUtil.extractInitializerError(e);
//        }
//    }
//
//    public static Config systemPropertiesAsConfig() {
//        return systemPropertiesAsConfigObject().toConfig();
//    }


}
