/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config;

import java.time.Duration;
import java.time.Period;
import java.time.temporal.TemporalAmount;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * 不可变的从path到值的映射。path用点如 foo.bar.baz,值为JSON (booleans, strings, numbers, lists, or objects)这个ConfigValue实例，不为null
 * 所有操作返回一个新的不可变的Config
 * <code>ConfigObject</code>是一个JSON对象，<code>Config</code>是一个configuration API.
 */
public interface Config extends ConfigMergeable {
    /**
     * 返回配置项的根配置
     */
    ConfigObject root();

    /**
     * 获得Config的源信息（文件，或文件中某一行，或描述短语）
     */
    ConfigOrigin origin();

    @Override
    Config withFallback(ConfigMergeable other);

    /**
     * 返回一个替换${}后的Config
     */
    Config resolve();

    /**
     * 返回一个替换${}后的Config，允许自定义配置
     */
    Config resolve(ConfigResolveOptions options);

    /**
     * 检查是否resolve完
     */
    boolean isResolved();

    /**
     * 用给定Config来resolve
     */
    Config resolveWith(Config source);

    /**
     * 用给定Config来resolve，并自定义
     */
    Config resolveWith(Config source, ConfigResolveOptions options);

    /**
     * 根据引用Config验证此Config，抛出异常，快速失败（更加友好）
     */
    void checkValid(Config reference, String... restrictToPaths);

    /**
     * 验证path是否有值，此值非空
     *
     * @param path the path expression
     * @return true if a non-null value is present at the path
     * @throws ConfigException.BadPath if the path expression is invalid
     */
    boolean hasPath(String path);

    /**
     * 验证path是否有值，此值可为空
     *
     * @param path the path expression
     * @return true if a value is present at the path, even if the value is null
     * @throws ConfigException.BadPath if the path expression is invalid
     */
    boolean hasPathOrNull(String path);

    /**
     * Returns true if the {@code Config}'s root object contains no key-value pairs.
     *
     * @return true if the configuration is empty
     */
    boolean isEmpty();

    /**
     * 遍历k-v
     */
    Set<Map.Entry<String, ConfigValue>> entrySet();

    /**
     * 是否值为null
     *
     * @param path the path expression
     * @return true if the value exists and is null, false if it exists and is not null
     * @throws ConfigException.BadPath if the path expression is invalid
     * @throws ConfigException.Missing if value is not set at all
     */
    boolean getIsNull(String path);

    boolean getBoolean(String path);

    Number getNumber(String path);

    int getInt(String path);

    long getLong(String path);

    double getDouble(String path);

    String getString(String path);

    public <T extends Enum<T>> T getEnum(Class<T> enumClass, String path);

    ConfigObject getObject(String path);

    Config getConfig(String path);

    Object getAnyRef(String path);

    ConfigValue getValue(String path);

    Long getBytes(String path);

    ConfigMemorySize getMemorySize(String path);

    @Deprecated Long getMilliseconds(String path);

    @Deprecated Long getNanoseconds(String path);

    /**
     * 10m
     */
    long getDuration(String path, TimeUnit unit);

    Duration getDuration(String path);

    Period getPeriod(String path);

    TemporalAmount getTemporal(String path);

    ConfigList getList(String path);

    List<Boolean> getBooleanList(String path);

    List<Number> getNumberList(String path);

    List<Integer> getIntList(String path);

    List<Long> getLongList(String path);

    List<Double> getDoubleList(String path);

    List<String> getStringList(String path);

    <T extends Enum<T>> List<T> getEnumList(Class<T> enumClass, String path);

    List<? extends ConfigObject> getObjectList(String path);

    List<? extends Config> getConfigList(String path);

    List<? extends Object> getAnyRefList(String path);

    List<Long> getBytesList(String path);

    List<ConfigMemorySize> getMemorySizeList(String path);

    @Deprecated List<Long> getMillisecondsList(String path);

    @Deprecated List<Long> getNanosecondsList(String path);

    List<Long> getDurationList(String path, TimeUnit unit);

    List<Duration> getDurationList(String path);

    /**
     * 克隆Config仅保留给定path
     */
    Config withOnlyPath(String path);

    /**
     * 克隆Config排除给定path
     */
    Config withoutPath(String path);

    /**
     * 将Config放在给定路径的另一个Config中
     */
    Config atPath(String path);

    /**
     * 将Config放在给定Key的另一个Config中
     */
    Config atKey(String key);

    /**
     * 设置k-v
     */
    Config withValue(String path, ConfigValue value);
}
