/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config;

import java.util.Map;

/**
 * 是ConfigValue和map的子类型
 */
public interface ConfigObject extends ConfigValue, Map<String, ConfigValue> {

    /**
     * 将对象转换为Config实例，可以来找到值
     *
     *  @return a {@link Config} with this object as its root
     */
    Config toConfig();

    /**
     * 递归地展开对象，将一个映射从String返回到从对象的值中解包的任何普通Java值。
     *
     * @return a {@link Map} containing plain Java objects
     */
    @Override
    Map<String, Object> unwrapped();

    @Override
    ConfigObject withFallback(ConfigMergeable other);

    /**
     * 返回ConfigValue
     * 
     * @param key
     *            key to look up
     * 
     * @return the value at the key or null if none
     */
    @Override
    ConfigValue get(Object key);

    /**
     * 克隆ConfigObject仅包含给定的key
     */
    ConfigObject withOnlyKey(String key);

    /**
     * 克隆ConfigObject仅排除给定的key
     */
    ConfigObject withoutKey(String key);

    /**
     * 设置k-v
     */
    ConfigObject withValue(String key, ConfigValue value);

    @Override
    ConfigObject withOrigin(ConfigOrigin origin);
}
