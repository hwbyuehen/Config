/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config;

/**
 * 设置ConfigValue渲染的选项
 * ConfigRenderOptions option = ConfigRenderOptions.defaults().setOriginComments(false)
 */
public final class ConfigRenderOptions {
    private final boolean originComments;
    private final boolean comments;
    private final boolean formatted;
    private final boolean json;

    private ConfigRenderOptions(boolean originComments, boolean comments, boolean formatted,
                                boolean json) {
        this.originComments = originComments;
        this.comments = comments;
        this.formatted = formatted;
        this.json = json;
    }

    public static ConfigRenderOptions defaults() {
        return new ConfigRenderOptions(true, true, true, true);
    }

    public static ConfigRenderOptions concise() {
        return new ConfigRenderOptions(false, false, false, true);
    }

    public ConfigRenderOptions setComments(boolean value) {
        if (value == comments)
            return this;
        else
            return new ConfigRenderOptions(originComments, value, formatted, json);
    }

    public boolean getComments() {
        return comments;
    }

    public ConfigRenderOptions setOriginComments(boolean value) {
        if (value == originComments)
            return this;
        else
            return new ConfigRenderOptions(value, comments, formatted, json);
    }

    public boolean getOriginComments() {
        return originComments;
    }

    public ConfigRenderOptions setFormatted(boolean value) {
        if (value == formatted)
            return this;
        else
            return new ConfigRenderOptions(originComments, comments, value, json);
    }

    public boolean getFormatted() {
        return formatted;
    }

    public ConfigRenderOptions setJson(boolean value) {
        if (value == json)
            return this;
        else
            return new ConfigRenderOptions(originComments, comments, formatted, value);
    }

    public boolean getJson() {
        return json;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("ConfigRenderOptions(");
        if (originComments)
            sb.append("originComments,");
        if (comments)
            sb.append("comments,");
        if (formatted)
            sb.append("formatted,");
        if (json)
            sb.append("json,");
        if (sb.charAt(sb.length() - 1) == ',')
            sb.setLength(sb.length() - 1);
        sb.append(")");
        return sb.toString();
    }
}
