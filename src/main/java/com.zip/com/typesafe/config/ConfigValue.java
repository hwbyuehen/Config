/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config;

/**
 * 一个不可变的值
 */
public interface ConfigValue extends ConfigMergeable {
    /**
     * 值的来源
     */
    ConfigOrigin origin();

    /**
     * 值的类型
     */
    ConfigValueType valueType();

    /**
     * 返回java值, a {@code String}, {@code Number}, {@code Boolean}, {@code Map<String,Object>},
     * {@code List<Object>}, or {@code null}, matching the {@link #valueType()}
     * of this {@code ConfigValue}. If the value is a {@link ConfigObject} or
     * {@link ConfigList}, 递归展开.
     * @return 与ConfigValue对应的普通的java值
     */
    Object unwrapped();

    /**
     * 返回这个值的HOCON字符串
     */
    String render();

    /**
     * 返回这个值的HOCON字符串（自定义显示内容及格式）
     */
    String render(ConfigRenderOptions options);

    @Override
    ConfigValue withFallback(ConfigMergeable other);

    /**
     * 在给定key设置Config路径
     */
    Config atPath(String path);

    /**
     * 在给定key设置Config值
     */
    Config atKey(String key);

    /**
     * 设置值的来源
     */
    ConfigValue withOrigin(ConfigOrigin origin);
}
