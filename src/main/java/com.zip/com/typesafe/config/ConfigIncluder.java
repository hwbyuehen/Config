/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config;

/**
 * {@link ConfigParseOptions#setIncluder ConfigParseOptions.setIncluder()}来自定义处理config文件的语句
 */
public interface ConfigIncluder {
    /**
     * 合并两个ConfigIncluder
     */
    ConfigIncluder withFallback(ConfigIncluder fallback);

    /**
     * 包含其他项
     * 
     * @param context
     *            some info about the include context
     * @param what
     *            the include statement's argument
     * @return a non-null ConfigObject
     */
    ConfigObject include(ConfigIncludeContext context, String what);
}
