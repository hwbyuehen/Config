/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config;

/**
 * 与解决替换相关的一组选项
 * <pre>
 *     ConfigResolveOptions options = ConfigResolveOptions.defaults()
 *         .setUseSystemEnvironment(false)
 * </pre>
 */
public final class ConfigResolveOptions {
    private final boolean useSystemEnvironment;
    private final boolean allowUnresolved;
    private final ConfigResolver resolver;

    private ConfigResolveOptions(boolean useSystemEnvironment, boolean allowUnresolved,
                                 ConfigResolver resolver) {
        this.useSystemEnvironment = useSystemEnvironment;
        this.allowUnresolved = allowUnresolved;
        this.resolver = resolver;
    }

    public static ConfigResolveOptions defaults() {
        return new ConfigResolveOptions(true, false, NULL_RESOLVER);
    }

    public static ConfigResolveOptions noSystem() {
        return defaults().setUseSystemEnvironment(false);
    }

    /**
     * 用系统参数设置resolve
     */
    public ConfigResolveOptions setUseSystemEnvironment(boolean value) {
        return new ConfigResolveOptions(value, allowUnresolved, resolver);
    }

    public boolean getUseSystemEnvironment() {
        return useSystemEnvironment;
    }

    public ConfigResolveOptions setAllowUnresolved(boolean value) {
        return new ConfigResolveOptions(useSystemEnvironment, value, resolver);
    }

    /**
     *  <pre>
     *     ConfigResolveOptions options = ConfigResolveOptions.defaults()
     *         .appendResolver(primary)
     *         .appendResolver(secondary)
     *         .appendResolver(tertiary);
     * </pre>
     */
    public ConfigResolveOptions appendResolver(ConfigResolver value) {
        if (value == null) {
            throw new ConfigException.BugOrBroken("null resolver passed to appendResolver");
        } else if (value == this.resolver) {
            return this;
        } else {
            return new ConfigResolveOptions(useSystemEnvironment, allowUnresolved,
                    this.resolver.withFallback(value));
        }
    }

    public ConfigResolver getResolver() {
        return this.resolver;
    }

    /**
     * 是否允许为处理的
     */
    public boolean getAllowUnresolved() {
        return allowUnresolved;
    }

    /**
     * Singleton resolver that never resolves paths.
     */
    private static final ConfigResolver NULL_RESOLVER = new ConfigResolver() {

        @Override
        public ConfigValue lookup(String path) {
            return null;
        }

        @Override
        public ConfigResolver withFallback(ConfigResolver fallback) {
            return fallback;
        }

    };

}
