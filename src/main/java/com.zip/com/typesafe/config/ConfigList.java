/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config;

import java.util.List;

/**
 * ConfigValue和list的子类型
 */
public interface ConfigList extends List<ConfigValue>, ConfigValue {

    /**
     * 以递归方式展开列表，返回普通Java值列表，如Integer或String或列表中的任何内容。
     *
     * @return a {@link List} containing plain Java objects
     */
    @Override
    List<Object> unwrapped();

    @Override
    ConfigList withOrigin(ConfigOrigin origin);
}
