/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config;


import com.typesafe.config.impl.ConfigImplUtil;

/**
 * 解析相关的一系列配置项
 * 不可变对象
 * ConfigParseOptions options = ConfigParseOptions.defaults()
 *         .setSyntax(ConfigSyntax.JSON)
 *         .setAllowMissing(false)
 */
public final class ConfigParseOptions {
    final ConfigSyntax syntax;//json，conf，properties类型
    final String originDescription;//源描述
    final boolean allowMissing;//是否允许丢失
    final ConfigIncluder includer;//includer
    final ClassLoader classLoader;//类加载器

    private ConfigParseOptions(ConfigSyntax syntax, String originDescription, boolean allowMissing,
                               ConfigIncluder includer, ClassLoader classLoader) {
        this.syntax = syntax;
        this.originDescription = originDescription;
        this.allowMissing = allowMissing;
        this.includer = includer;
        this.classLoader = classLoader;
    }

    /**
     * 创建默认类
     */
    public static ConfigParseOptions defaults() {
        return new ConfigParseOptions(null, null, true, null, null);
    }

    public ConfigParseOptions setSyntax(ConfigSyntax syntax) {
        if (this.syntax == syntax)
            return this;
        else
            return new ConfigParseOptions(syntax, this.originDescription, this.allowMissing,
                    this.includer, this.classLoader);
    }

//    public ConfigParseOptions setSyntaxFromFilename(String filename) {
//        ConfigSyntax syntax = ConfigImplUtil.syntaxFromExtension(filename);
//        return setSyntax(syntax);
//    }

    public ConfigSyntax getSyntax() {
        return syntax;
    }

    public ConfigParseOptions setOriginDescription(String originDescription) {
        // findbugs complains about == here but is wrong, do not "fix"
        if (this.originDescription == originDescription)
            return this;
        else if (this.originDescription != null && originDescription != null
                && this.originDescription.equals(originDescription))
            return this;
        else
            return new ConfigParseOptions(this.syntax, originDescription, this.allowMissing,
                    this.includer, this.classLoader);
    }

    public String getOriginDescription() {
        return originDescription;
    }

    /** this is package-private, not public API */
    ConfigParseOptions withFallbackOriginDescription(String originDescription) {
        if (this.originDescription == null)
            return setOriginDescription(originDescription);
        else
            return this;
    }

    public ConfigParseOptions setAllowMissing(boolean allowMissing) {
        if (this.allowMissing == allowMissing)
            return this;
        else
            return new ConfigParseOptions(this.syntax, this.originDescription, allowMissing,
                    this.includer, this.classLoader);
    }

    public boolean getAllowMissing() {
        return allowMissing;
    }

    public ConfigParseOptions setClassLoader(ClassLoader loader) {
        if (this.classLoader == loader)
            return this;
        else
            return new ConfigParseOptions(this.syntax, this.originDescription, this.allowMissing,
                    this.includer, loader);
    }
    
    public ClassLoader getClassLoader() {
        if (this.classLoader == null)
            return Thread.currentThread().getContextClassLoader();
        else
            return this.classLoader;
    }
}
