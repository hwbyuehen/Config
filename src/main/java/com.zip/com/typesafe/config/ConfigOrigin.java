/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.typesafe.config;

import java.net.URL;
import java.util.List;


/**
 * 值的来源
 * origin（文件名，资源地址，描述等信息），debug用的相关信息（行号，路径）
 */
public interface ConfigOrigin {
    /**
     * 返回值或异常的源的描述信息
     */
    public String description();

    /**
     * 返回源的文件名
     *
     * @return 文件名 or null
     */
    public String filename();

    /**
     * 返回源的URL
     *
     * @return url or null
     */
    public URL url();

    /**
     * 返回源的资源路径
     *
     * @return 资源路径 or null
     */
    public String resource();

    /**
     * 返回值或异常的行号
     *
     * @return 行号 or -1 if none is available
     */
    public int lineNumber();

    /**
     * 返回去往这个源的路径
     * 
     * @return 路径, empty list if none
     */
    public List<String> comments();

    /**
     * 设置comments
     * 
     * @return the ConfigOrigin with the given comments
     */
    public ConfigOrigin withComments(List<String> comments);

    /**
     * 设置行号
     * 
     * @return the created ConfigOrigin
     */
    public ConfigOrigin withLineNumber(int lineNumber);
}
