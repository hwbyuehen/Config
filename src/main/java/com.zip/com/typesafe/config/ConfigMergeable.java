package com.typesafe.config;

/**
 * @author 吃土的飞鱼 
 */
public interface ConfigMergeable {
    /**
     * 合并两个返回合并后的一个
     * @param other
     * @return
     */
    ConfigMergeable withFallback(ConfigMergeable other);
}
