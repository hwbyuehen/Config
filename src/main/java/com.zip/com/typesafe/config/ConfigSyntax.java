package com.typesafe.config;

/**
 * 字符流的语法，json，conf，properties
 * 
 */
public enum ConfigSyntax {
    JSON,
    CONF,
    PROPERTIES;
}
