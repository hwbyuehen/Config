package com.typesafe.config;

/**
 * 提供当遇到未resolve时的resolve行为
 * {@link ConfigResolveOptions#appendResolver ConfigResolveOptions.appendResolver()}
 */
public interface ConfigResolver {

    /**
     * 返回替代给定未resolve的path的值
     */
    public ConfigValue lookup(String path);

    /**
     * 如果这个不能提供替换自己的resolver时返回新的
     */
    public ConfigResolver withFallback(ConfigResolver fallback);

}
