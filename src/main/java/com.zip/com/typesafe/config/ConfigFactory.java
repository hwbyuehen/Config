package com.typesafe.config;

import com.typesafe.config.impl.ConfigImpl;

import java.io.File;
import java.util.concurrent.Callable;

/**
 * Created by 吃土的飞鱼 on 2018/9/7.
 */
public final class ConfigFactory {
    private static final String STRATEGY_PROPERTY_NAME = "config.strategy";

    private ConfigFactory() {
    }

//    /**
//     * 返回给定classpath资源或资源文件夹名，resolves
//     * 没有/
//     */
//    public static Config load(String resourceBasename) {
//        return load(resourceBasename, ConfigParseOptions.defaults(),
//                ConfigResolveOptions.defaults());
//    }
//
//    public static Config load(ClassLoader loader, String resourceBasename) {
//        return load(resourceBasename, ConfigParseOptions.defaults().setClassLoader(loader),
//                ConfigResolveOptions.defaults());
//    }
//
//    /**
//     * Like {@link #load(String)} 可以自定义parse和resolve.
//     *
//     * @param resourceBasename the classpath resource name with optional extension
//     * @param parseOptions options to use when parsing the resource
//     * @param resolveOptions options to use when resolving the stack
//     * @return configuration for an application
//     */
//    public static Config load(String resourceBasename, ConfigParseOptions parseOptions,
//                              ConfigResolveOptions resolveOptions) {
//        ConfigParseOptions withLoader = ensureClassLoader(parseOptions, "load");
//        Config appConfig = ConfigFactory.parseResourcesAnySyntax(resourceBasename, withLoader);
//        return load(withLoader.getClassLoader(), appConfig, resolveOptions);
//    }
//
//    public static Config load(ClassLoader loader, String resourceBasename,
//                              ConfigParseOptions parseOptions, ConfigResolveOptions resolveOptions) {
//        return load(resourceBasename, parseOptions.setClassLoader(loader), resolveOptions);
//    }

    /**
     * 获取当前线程ClassLoader
     * @param methodName
     * @return
     */
    private static ClassLoader checkedContextClassLoader(String methodName) {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        if (loader == null)
            throw new ConfigException.BugOrBroken("Context class loader is not set for the current thread; "
                    + "if Thread.currentThread().getContextClassLoader() returns null, you must pass a ClassLoader "
                    + "explicitly to ConfigFactory." + methodName);
        else
            return loader;
    }
//
//    /**
//     * 设置parser选项的ClassLoader为当前线程的ClassLoader
//     * @param options
//     * @param methodName
//     * @return
//     */
//    private static ConfigParseOptions ensureClassLoader(ConfigParseOptions options, String methodName) {
//        if (options.getClassLoader() == null)
//            return options.setClassLoader(checkedContextClassLoader(methodName));
//        else
//            return options;
//    }
//
//    public static Config load(Config config) {
//        return load(checkedContextClassLoader("load"), config);
//    }
//
//    public static Config load(ClassLoader loader, Config config) {
//        return load(loader, config, ConfigResolveOptions.defaults());
//    }
//
//    public static Config load(Config config, ConfigResolveOptions resolveOptions) {
//        return load(checkedContextClassLoader("load"), config, resolveOptions);
//    }
//
//    public static Config load(ClassLoader loader, Config config, ConfigResolveOptions resolveOptions) {
//        return defaultOverrides(loader).withFallback(config).withFallback(defaultReference(loader))
//                .resolve(resolveOptions);
//    }

    public static Config load() {
        ClassLoader loader = checkedContextClassLoader("load");
        return load(loader);
    }

    public static Config load(final ClassLoader loader) {
        final ConfigParseOptions withLoader = ConfigParseOptions.defaults().setClassLoader(loader);
        return ConfigImpl.computeCachedConfig(loader, "load", new Callable<Config>() {
            @Override
            public Config call() {
//                return load(loader, defaultApplication(withLoader));TODO
                return null;
            }
        });
    }


    
}
